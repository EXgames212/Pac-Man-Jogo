extends Area2D


func _on_body_entered(body: Node2D) -> void:
	if body.name == "pacman":
		var main = get_parent()
		main.pontosPacMan += 1
		print("PacMan 1: ", main.pontosPacMan)
		queue_free()
		print("pontuou")

	elif body.name == "MissPacMan":
		var main = get_parent()
		main.pontosMissPacMan += 1
		print("Miss PacMan: ", main.pontosMissPacMan)
		queue_free()
		print("pontuou")

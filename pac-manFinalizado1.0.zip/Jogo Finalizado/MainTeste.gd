extends Node
var pontosPacMan = 0
var pontosMissPacMan = 0
var tamTela: Vector2

func _ready() -> void:
	$pacman.position.x = 400
	$MissPacMan.position.y = 300


func _process(delta: float) -> void:
	pass

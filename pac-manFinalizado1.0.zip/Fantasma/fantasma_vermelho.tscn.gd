extends CharacterBody2D

@export var speed: float = 90.0
var target: Node2D = null

@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D

enum State { INSIDE_HOUSE, LEAVING_HOUSE, CHASING }
var current_state: State = State.LEAVING_HOUSE

@export var exit_position: Vector2 

func _ready() -> void:
	nav_agent.path_desired_distance = 4.0
	nav_agent.target_desired_distance = 4.0
	
	if exit_position == Vector2.ZERO:
		exit_position = global_position + Vector2(0, -32)

func _physics_process(_delta: float) -> void:
	match current_state:
		State.LEAVING_HOUSE:
			move_out_of_house()
		State.CHASING:
			chase_pacman()
		

func move_out_of_house() -> void:
	var direction = (exit_position - global_position).normalized()
	velocity = direction * speed
	move_and_slide()
	
	if global_position.distance_to(exit_position) < 4.0:
		current_state = State.CHASING

func chase_pacman() -> void:
	if not target:
		find_pacman()
		return

	nav_agent.target_position = target.global_position

	if nav_agent.is_navigation_finished():
		velocity = Vector2.ZERO
		return

	var next_path_position: Vector2 = nav_agent.get_next_path_position()
	var raw_direction: Vector2 = (next_path_position - global_position).normalized()
	
	var direction: Vector2 = Vector2.ZERO

	if abs(raw_direction.x) > abs(raw_direction.y):
		direction = Vector2(sign(raw_direction.x), 0) 
	else:
		direction = Vector2(0, sign(raw_direction.y)) 
	

	velocity = direction * speed
	move_and_slide()

func find_pacman() -> void:
	var players = get_tree().get_nodes_in_group("player")
	if players.size() > 0:
		target = players[0]

func _on_hitbox_body_entered(body: Node2D) -> void:
	if body.is_in_group("Pacman") or body.has_method("die"):
		body.die()

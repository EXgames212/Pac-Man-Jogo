extends CharacterBody2D

@export var speed: float = 90.0
var target: Node2D = null

@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D

enum State { INSIDE_HOUSE, LEAVING_HOUSE, CHASING }
var current_state: State = State.LEAVING_HOUSE

@export var exit_position: Vector2


func _ready() -> void:
	nav_agent.path_desired_distance = 4.0
	nav_agent.target_desired_distance = 4.0

	$hitbox.body_entered.connect(_on_hitbox_body_entered)

	if exit_position == Vector2.ZERO:
		exit_position = global_position + Vector2(0, -32)


func _physics_process(_delta: float) -> void:
	match current_state:
		State.LEAVING_HOUSE:
			move_out_of_house()

		State.CHASING:
			chase_pacman()

func move_out_of_house() -> void:
	var direction = (exit_position - global_position).normalized()

	velocity = direction * speed
	move_and_slide()

	if global_position.distance_to(exit_position) < 4.0:
		current_state = State.CHASING
		find_pacman()


func chase_pacman() -> void:
	find_pacman()

	if not target:
		velocity = Vector2.ZERO
		return

	nav_agent.target_position = target.global_position

	if nav_agent.is_navigation_finished():
		velocity = Vector2.ZERO
		return

	var next_path_position: Vector2 = nav_agent.get_next_path_position()
	var raw_direction: Vector2 = (next_path_position - global_position).normalized()

	var direction: Vector2 = Vector2.ZERO

	if abs(raw_direction.x) > abs(raw_direction.y):
		direction = Vector2(sign(raw_direction.x), 0)
	else:
		direction = Vector2(0, sign(raw_direction.y))

	velocity = direction * speed
	move_and_slide()


func find_pacman() -> void:
	var players = get_tree().get_nodes_in_group("player")

	if players.size() == 0:
		target = null
		return

	var jogador_mais_perto = players[0]
	var menor_distancia = global_position.distance_to(players[0].global_position)

	for jogador in players:
		if not is_instance_valid(jogador):
			continue

		var distancia = global_position.distance_to(jogador.global_position)

		if distancia < menor_distancia:
			menor_distancia = distancia
			jogador_mais_perto = jogador

	target = jogador_mais_perto


func _on_hitbox_body_entered(body: Node2D) -> void:
	if body.has_method("die"):
		body.die()

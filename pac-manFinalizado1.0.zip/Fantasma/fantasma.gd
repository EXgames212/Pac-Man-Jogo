extends CharacterBody2D

@export var speed: float = 100.0

# As 4 direções cardinais
const DIRECTIONS = [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]

var current_direction: Vector2 = Vector2.ZERO

func _ready() -> void:
	# No Godot 4, randomize() não é necessário no _ready (o motor faz isso automaticamente)
	choose_random_direction()

func _physics_process(_delta: float) -> void:
	velocity = current_direction * speed
	
	# move_and_slide() atualiza as propriedades de colisão como is_on_wall()
	move_and_slide()
	
	# Se bateu em uma parede, escolhe uma direção válida diferente da atual
	if is_on_wall():
		choose_new_direction()

func choose_random_direction() -> void:
	current_direction = DIRECTIONS.pick_random()

func choose_new_direction() -> void:
	# Filtra apenas direções que NÃO sejam a direção atual que causou a colisão
	var available_directions: Array[Vector2] = []
	
	for dir in DIRECTIONS:
		if dir != current_direction:
			available_directions.append(dir)
	
	# Escolhe uma nova direção entre as opções válidas
	if available_directions.size() > 0:
		current_direction = available_directions.pick_random()
	else:
		# Caso extremo: inverte o sentido
		current_direction = -current_direction


func _on_body_entered(body: Node2D) -> void:
	pass # Replace with function body.

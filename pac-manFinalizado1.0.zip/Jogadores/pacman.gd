extends CharacterBody2D

# Velocidade de movimento
@export var speed: float = 120.0

# Referência aos nós filhos
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var waka_sound: AudioStreamPlayer2D = $AudioStreamPlayer2D

# Alternador para fazer o som mudar de tom ("Wa-Ka")
var toggle_pitch: bool = false

func _ready() -> void:
	# Conecta o sinal nativo do Godot que avisa quando o frame do sprite mudou
	animated_sprite.frame_changed.connect(_on_animated_sprite_frame_changed)

func _physics_process(_delta: float) -> void:
	# Captura o movimento das teclas
	var input_direction: Vector2 = Input.get_vector("Esquerda1", "Direita1", "Cima1", "Baixo1")
	input_direction = normalize_cardinal_direction(input_direction)
	
	velocity = input_direction * speed
	move_and_slide()
	
	# Controla a animação e a rotação
	update_animation(input_direction)

func normalize_cardinal_direction(dir: Vector2) -> Vector2:
	if abs(dir.x) > 0.0:
		return Vector2(sign(dir.x), 0)
	elif abs(dir.y) > 0.0:
		return Vector2(0, sign(dir.y))
	return Vector2.ZERO

func update_animation(dir: Vector2) -> void:
	if dir != Vector2.ZERO:
		animated_sprite.play("pacman")
		match dir:
			Vector2.RIGHT:
				animated_sprite.rotation_degrees = 0
			Vector2.LEFT:
				animated_sprite.rotation_degrees = 180
			Vector2.DOWN:
				animated_sprite.rotation_degrees = 90
			Vector2.UP:
				animated_sprite.rotation_degrees = 270
	else:
		# Quando o jogador para de andar:
		animated_sprite.stop()
		animated_sprite.frame = 0
		waka_sound.stop() # <- Corta o som imediatamente ao parar!
func _on_animated_sprite_frame_changed() -> void:
	# Só toca o som se o Pac-Man estiver realmente a mover-se
	if animated_sprite.animation == "pacman" and velocity != Vector2.ZERO:
		if animated_sprite.frame == 2:
			play_waka_sound()

func play_waka_sound() -> void:
	# Alterna o tom do som levemente a cada morder para dar o efeito "Wa-Ka"
	waka_sound.pitch_scale = 1.10 if toggle_pitch else 1.0
	toggle_pitch = !toggle_pitch
	
	# Toca o áudio
	waka_sound.play()
func die() -> void:
	print("PacMan morreu!")
	print("MissPacMan venceu!")
	queue_free()

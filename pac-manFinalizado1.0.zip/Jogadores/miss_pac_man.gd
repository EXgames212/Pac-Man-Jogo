extends CharacterBody2D
 
@export var speed: float = 120.0 
 
@onready var waka_sound: AudioStreamPlayer2D = $AudioStreamPlayer2D 
 
var toggle_pitch: bool = false 
 
func _physics_process(_delta: float) -> void:  
	var input_direction: Vector2 = Input.get_vector("Esquerda2", "Direita2", "Cima2", "Baixo2") 
	input_direction = normalize_cardinal_direction(input_direction) 
	 
	velocity = input_direction * speed 
	move_and_slide() 

	if input_direction != Vector2.ZERO: 
		if !waka_sound.playing:
			play_waka_sound()
	else: 
		waka_sound.stop()
 
func normalize_cardinal_direction(dir: Vector2) -> Vector2: 
	if abs(dir.x) > 0.0: 
		return Vector2(sign(dir.x), 0) 
	elif abs(dir.y) > 0.0: 
		return Vector2(0, sign(dir.y)) 
	return Vector2.ZERO 
 
func play_waka_sound() -> void: 
	waka_sound.pitch_scale = 1.25 if toggle_pitch else 1.10
	toggle_pitch = !toggle_pitch 
	 
	waka_sound.play()
func die() -> void:
	print("MissPacMan morreu!")
	print("PacMan venceu!")
	queue_free()

extends Area2D

func _ready() -> void:
	pass

func _on_coin_body_entered(body):
	if body.has_method("player"):
		game.game_score += 1
		print(game.game_score)
		queue_free() 
		print("pontuou")
	pass
